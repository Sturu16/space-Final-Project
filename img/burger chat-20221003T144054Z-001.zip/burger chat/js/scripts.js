function showmenu(){
    let simagle = document.getElementById("mainnav").style.height;

    console.log(simagle);

    if(simagle == "150px"){
        document.getElementById("mainnav").style.height = "0px";
    }
    else{
        document.getElementById("mainnav").style.height = "150px";
    }
    
}